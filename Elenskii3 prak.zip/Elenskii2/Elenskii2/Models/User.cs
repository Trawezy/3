﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elenskii2.Models
{
    public class User
    {
        public int userId { get; set; }
        public string login { get; set; }
        public string password { get; set; }
        public bool isAdmin { get; set; }
    }
}
