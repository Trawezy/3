﻿using Elenskii2.Contexts;
using Elenskii2.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Elenskii2.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string name = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        private IEnumerable<User> _users;
        public IEnumerable<User> USERS
        {
            get
            {
                return _users;
            }
            set
            {
                _users = value;
                OnPropertyChanged();
            }
        }

        private void GetUser()
        {
            using (var context = new Context())
            {
                USERS = context.Users.ToList();
            }
        }

        private IEnumerable<ADMIN> _admins;
        public IEnumerable<ADMIN> admins
        {
            get
            {
                return _admins;
            }
            set
            {
                _admins = value;
                OnPropertyChanged();
            }
        }

        private void GetADMIN()
        {
            using (var context = new Context())
            {
                admins = context.admins.ToList();
            }
        }

        public MainViewModel()
        {
            GetUser();
            GetADMIN();
        }
    }
}
